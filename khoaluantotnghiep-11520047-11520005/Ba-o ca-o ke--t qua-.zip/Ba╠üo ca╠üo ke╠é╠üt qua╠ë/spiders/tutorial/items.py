import scrapy
class DmozItem(scrapy.Item):
    data = scrapy.Field()
    #cookies = scrapy.Field()
